import sys
import webbrowser
import google.generativeai as genai
import time
import subprocess
from PySide6.QtWidgets import (
    QApplication, QWidget, QVBoxLayout, QTextEdit,
    QLineEdit, QPushButton, QLabel, QHBoxLayout
)
from PySide6.QtGui import QFont
from PySide6.QtCore import Qt
# ================= AI SETUP =================
genai.configure(api_key="YOUR_API_KEY_HERE") #This is your api key, make sure to replace it

model = genai.GenerativeModel(
    "gemini-2.5-flash",
    system_instruction="""
You are a smart and techy AI assistant.
You help the user efficiently but with personality.

Your personality is humorous, a bit of Generation Z slang, smart, and techy.
You can lightly roast the user occasionally, but do not overdo it.

IMPORTANT:
- Only call a function when the user explicitly asks to perform an action (like opening a website or app).
- Do NOT call functions for normal conversation (like greetings, questions, or chat).
- Never mention function names or that you are calling a function.
"""
)

# ================= FUNCTION =================
def open_website(url: str):
    webbrowser.open(url)

# ================= TOOLS =================
tools = [
    {
        "function_declarations": [
            {
                "name": "open_website",
                "description": "Open any website like YouTube, Google, GitHub using a URL",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "url": {
                            "type": "string",
                            "description": "The website URL to open"
                        }
                    },
                    "required": ["url"]
                }
            }
        ]
    }
]

# ================= FUNCTION MAP =================
functions = {
    "open_website": open_website
}

# ================= PROCESS FUNCTION =================
def process_input(user_input):
    response = model.generate_content(user_input, tools=tools)

    candidate = response.candidates[0]
    did_call = False
    output_text = ""

    # 🔥 FIRST: check function calls
    for part in candidate.content.parts:
        if hasattr(part, "function_call") and part.function_call is not None:
            fn = part.function_call

    if fn.name in functions and fn.args:
        functions[fn.name](**fn.args)
        did_call = True


    try:
        output_text = candidate.content.parts[0].text
    except:
        output_text = ""

    if output_text and output_text.strip():
        return output_text
    elif did_call:
        return "Done 😏"
    else:
        return "..."

    
    
#GUI (Yayy PySide6 and no tkinter!!)
app = QApplication(sys.argv)
window = QWidget()

window.setWindowTitle("ZeldAI V3 - The Gen Z AI Assistant")

layout = QVBoxLayout()

# Widgets
ChatBox = QTextEdit()
ChatBox.setReadOnly(True)

TextInput = QLineEdit()
SendButton = QPushButton("Send")

layout.addWidget(ChatBox)
layout.addWidget(TextInput)
layout.addWidget(SendButton)

window.setLayout(layout)

window.setStyleSheet("""
QWidget {
    background-color: #121212;
    color: #ffffff;
}
QLineEdit {
    background-color: #1e1e1e;
    color: white;
    padding: 8px;
    border-radius: 10px;
}
QTextEdit {
    background-color: #1e1e1e;
    color: white;
    border-radius: 10px;
}
QPushButton {
    background-color: #4CAF50;
    color: white;
    border-radius: 10px;
    padding: 8px;
}
QPushButton:hover {
    background-color: #45a049;
}
""")

def on_send():
    user_text = TextInput.text()

    if not user_text.strip():
        return

    ChatBox.append("You: " + user_text)

    reply = process_input(user_text)

    ChatBox.append("AI: " + reply)

    TextInput.clear()

SendButton.clicked.connect(on_send)

window.show()
sys.exit(app.exec())