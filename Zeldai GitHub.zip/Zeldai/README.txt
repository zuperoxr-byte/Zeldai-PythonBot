For running this bot you will need the following:

Python 3.10+ (Reccomended 3.11 or 3.12)

google-generativeai library

PySide6

Your own gemini api key

Internet

CPU - any modern processor

Ram: 4GB minimum (8GB better)

Gemini API 2.5 flash model